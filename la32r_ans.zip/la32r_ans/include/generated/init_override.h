void la32r_init() {
	printk("init.c:\tla32r_init() is called\n");

	la32r_detect_memory();
	la32r_vm_init();
	page_init();
	env_init();

 ENV_CREATE(user_icode); ENV_CREATE(fs_serv);

	schedule(0);
	panic("init.c:\tend of la32r_init() reached!");
}
