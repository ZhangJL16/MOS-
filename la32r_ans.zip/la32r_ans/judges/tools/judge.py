#!/usr/bin/python3

# for Quartz cases:
#   - execute.command: $QUARTZ_PROBLEM_ROOT/resources/judge -vd $QUARTZ_PROBLEM_ROOT/resources/lab{x}_{y}*
#     - 输出详细日志到 stdout，评测结果到 stderr

from __future__ import annotations
import os
import sys
import subprocess
import shlex
import signal
import argparse
import traceback
from typing import Iterator, Sequence, BinaryIO

import psutil
import utils
from utils import *

verbose = False

common_scope = {
    k: getattr(utils, k)
    for k in dir(utils)
    if not k.startswith('_')
}


class Case:
    def __init__(self, id: str, script: Sequence[str], lines: list[str], permissive_indices: set[int]) -> None:
        self.id = id
        self.name = None
        self.score = None
        self.lines = lines
        self.permissive_indices = permissive_indices
        self.post = None
        self.cur = 0

        if script:
            def name(s):
                self.name = str(s)

            def score(s):
                self.score = int(s)

            def post(f):
                self.post = f

            def permissive():
                self.permissive_indices = True

            scope = {
                **common_scope,
                'name': name,
                'score': score,
                'post': post,
                'permissive': permissive,
                'self': self,
            }
            exec('def runit():\n' + '\n'.join(script), scope)
            scope['runit']()
        else:
            scope = None

        if not self.lines:
            raise ValueError(f'Case {id} has no patterns')

        if self.permissive_indices is not True:
            self.permissive_indices = frozenset(self.permissive_indices)
        self.lines = [l.encode() for l in self.lines]
        self.scope = scope
        self.len = len(self.lines)

    @property
    def passed(self) -> bool:
        return self.cur >= self.len

    @passed.setter
    def passed(self, v: bool) -> None:
        if v:
            yellow(f'Case {self.id} is forcibly passed')
            self.cur = self.len
        else:
            yellow(f'Case {self.id} is forcibly failed')
            self.cur = 0

    def __repr__(self) -> str:
        return f'<Case: {self.id}, {self.name}, {self.score}>'

    def __str__(self) -> str:
        if self.name:
            return self.name
        return self.id

    # Returns: (hit, done)
    def check(self, line: bytes, trusty: bool) -> tuple[bool, bool]:
        try:
            pattern = self.lines[self.cur]
        except IndexError:
            return False, True

        if (trusty or self.permissive_indices is True or self.cur in self.permissive_indices) and pattern in line:
            self.cur += 1
            if verbose:
                green(f'Hit {repr(pattern)[1:]} ({self.id}: {self.cur}/{self.len})')
            if self.passed:
                return True, True
            return True, False
        return False, False

    def missing_patterns(self) -> Sequence[bytes]:
        return self.lines[self.cur:self.len]


def parse_cases(fp) -> dict[str, Case]:
    case_id = '#'
    script = []
    lines = []
    permissive_indices = set()
    in_script = True
    unnamed_cnt = 1
    res = {}

    def flush_case(new_id=None):
        nonlocal case_id, script, in_script, lines, permissive_indices
        if script or lines:
            res[case_id] = Case(case_id, script, lines, permissive_indices)
        if new_id:
            if new_id in res:
                raise ValueError(f'Duplicate case id: {new_id}')
            case_id = new_id
        else:
            nonlocal unnamed_cnt
            case_id = f'#{unnamed_cnt}'
            unnamed_cnt += 1
        script = []
        lines = []
        permissive_indices = set()
        in_script = True

    for line in fp:
        line = line.rstrip()
        if line == 'from mostd import *' or not line.strip() or line.startswith('#'):
            continue
        if line == ':' or (line.endswith(':') and (
            line.startswith('def ') or line.startswith('class ')
        )):
            if line == ':':
                cid = None
            else:
                cid = line[line.find(' ') + 1:line.find('(')]
                if cid == '_':
                    cid = None
            flush_case(cid)
        elif line.startswith('    '):
            if not in_script:
                flush_case()
            script.append(line)
        else:
            in_script = False
            if line[0] == line[-1] == "'":
                line = line[1:-1].replace("\\'", "'")
            elif line[0] == line[-1] == '"':
                line = line[1:-1].replace('\\"', '"')
                permissive_indices.add(len(lines))
            lines.append(line)
    flush_case()
    return res


CHILD_TIMEOUT = 30
CHILD_TERM_TIMEOUT = 5


def eliminate_child(ch):
    try:
        proc = psutil.Process(ch.pid)
    except psutil.NoSuchProcess:
        return

    if ch.stdin:
        try:
            ch.stdin.close()
        except RuntimeError:
            # reentrant call fails in a signal handler
            pass

    if ch.stdout:
        try:
            if verbose:
                os.set_blocking(ch.stdout.fileno(), False)
                b = ch.stdout.read()
                if b:
                    sys.stdout.buffer.write(b'Remaining buffer: ' + b)
                    sys.stdout.flush()
            ch.stdout.close()

        except RuntimeError:
            pass

    chs = [proc]
    chs.extend(proc.children(recursive=True))

    alive = []
    for p in chs:
        try:
            p.terminate()
            alive.append(p)
        except psutil.NoSuchProcess:
            pass

    _, alive = psutil.wait_procs(alive, timeout=CHILD_TERM_TIMEOUT)
    for p in alive:
        try:
            yellow(f'Killing process {p.pid} ({p.name()})')
            p.kill()
        except psutil.NoSuchProcess:
            pass

    ch.wait()


def decrypt(out: BinaryIO, begin: bytes, end: bytes) -> Iterator[(bytes, bool)]:
    # ... end ... begin .. end ... begin ... end ... begin ...
    trusty = False
    for line in out:
        parts = line.split(begin)
        res = []
        res_trusty = []
        line_trusty = True

        def add(s):
            nonlocal line_trusty
            if s:
                line_trusty = line_trusty and trusty
                res.append(s)
                if trusty:
                    res_trusty.append(s)

        for i, part in enumerate(parts):
            t = part.split(end, 1)
            if i > 0:
                trusty = True
            add(t[0])
            if len(t) > 1:
                trusty = False
                add(t[1])

        yield b''.join(res), line_trusty
        if not line_trusty and res_trusty:
            yield b''.join(res_trusty), True


LENGTH_LIMIT = 2048


def len_limit(out: BinaryIO) -> Iterator[bytes]:
    while True:
        try:
            line = out.readline(LENGTH_LIMIT)
        except ValueError:
            break
        if line:
            yield line
        else:
            break


def main(args):
    if args.judge_dir:
        judge_dir = args.lab_name
    else:
        judge_dir = 'judges/' + args.lab_name

    global verbose
    verbose = args.verbose

    if args.cmd:
        cmd = shlex.split(args.cmd)
    else:
        entry = judge_dir + '/run'
        if os.access(entry, os.X_OK):
            cmd = [entry]
        else:
            cmd = ['make', 'run']

    if verbose:
        green(f'Exec {cmd}')

    add_flag('MAKEFLAGS', 's'),
    add_flag('PYTHONPATH', os.path.dirname(os.path.realpath(__file__)), sep=':')

    standard_out = judge_dir + '/standard'
    if not os.path.isfile(standard_out):
        standard_out = judge_dir
        if not os.path.isfile(standard_out):
            standard_out += '.py'

    if os.path.isfile(standard_out):
        with open(standard_out, encoding='utf-8') as fp:
            case_map = parse_cases(fp)
        cases = list(case_map.values())

        ch = subprocess.Popen(cmd,
                              stdin=None if args.stdin else subprocess.PIPE,
                              stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT if verbose else subprocess.DEVNULL,
                              start_new_session=True,  # for killpg
                              )
        ch_stdout = len_limit(ch.stdout)

        try:
            with open('.mos-crypt-begin', 'rb') as fp:
                crypt_begin = fp.read().strip()
        except FileNotFoundError:
            if args.encrypted:
                raise
            lines = ((line, True) for line in ch_stdout)
        else:
            with open('.mos-crypt-end', 'rb') as fp:
                crypt_end = fp.read().strip()
            lines = decrypt(ch_stdout, crypt_begin, crypt_end)
            green(f'Crypt key: {crypt_begin.hex()} / {crypt_end.hex()}')

        def on_timeout(*_):
            if ch:
                red(f'Emulator timed out after {CHILD_TIMEOUT} seconds')
                eliminate_child(ch)

        signal.signal(signal.SIGALRM, on_timeout)
        signal.alarm(CHILD_TIMEOUT)

        alive_cases = tuple(cases)
        post_cases = tuple(c for c in cases if c.post)
        all_out = []
        try:
            for out, trusty in lines:
                if post_cases and trusty:
                    all_out.append(out)
                if verbose:
                    sys.stdout.buffer.write(out if trusty else (b'(u) ' + out))
                    sys.stdout.flush()

                new_cases = []
                hit = False

                for c in alive_cases:
                    if hit:
                        new_cases.append(c)
                    else:
                        hit, done = c.check(out, trusty)
                        if not done:
                            new_cases.append(c)

                alive_cases = new_cases
                if not alive_cases:
                    # Early exit in case the emulator hangs after Accepted.
                    break
        finally:
            signal.alarm(0)
            eliminate_child(ch)

        if post_cases:
            # Decode with replacement to avoid errors.
            out = b'\n'.join(all_out).decode(errors='replace')
            for c in post_cases:
                if c.post:
                    c.scope['cases'] = case_map
                    c.scope['passed'] = c.passed
                    try:
                        c.post(out)
                    except Exception:
                        red(f'{c.id}: post-check failed')
                        traceback.print_exc(file=sys.stdout)

        inner_tot = sum(c.len for c in cases)
        inner_cnt = inner_tot - sum(c.len - c.cur for c in cases)
        if inner_cnt < inner_tot:
            bred(f'Wrong Answer ({inner_cnt}/{inner_tot} passed)')
            if verbose:
                for c in alive_cases:
                    for s in c.missing_patterns():
                        red(f'Missing: {repr(s)[1:]} ({c.id})')

            # TODO: 使用 quartz 提供的接口反馈得分
            ret = 1 + 100 * inner_cnt // inner_tot
        else:
            bgreen(f'Passed MOS test ({inner_tot} cases)')
            ret = 0

        for c in cases:
            if c.name:
                if c.passed:
                    bgreen(f'Passed: "{c.name}"')
                else:
                    bred(f'Failed: "{c.name}"')

        return ret

    if not os.path.exists(judge_dir):
        raise FileNotFoundError(judge_dir)

    p = subprocess.Popen(cmd,
                         stdin=subprocess.PIPE,
                         stderr=subprocess.STDOUT,
                         start_new_session=True,
                         )
    try:
        p.wait(CHILD_TIMEOUT)
    except subprocess.TimeoutExpired:
        bred(f'Child timed out after {CHILD_TIMEOUT} seconds')
        return 1
    finally:
        eliminate_child(p)

    if p.returncode != 0:
        bred(f'Child failed ({p.returncode})')
        return p.returncode

    bgreen('Passed MOS test')


if __name__ == '__main__':
    args = argparse.ArgumentParser()
    args.add_argument('lab_name')
    args.add_argument('-c', '--cmd')
    args.add_argument('-v', '--verbose', action='store_true')
    args.add_argument('-d', '--judge-dir', action='store_true')
    args.add_argument('-f', '--force', action='store_true')
    args.add_argument('-i', '--stdin', action='store_true')
    args.add_argument('-e', '--encrypted', action='store_true')
    args = args.parse_args()
    r = main(args)
    if r and not args.force:
        sys.exit(r)
