from utils import *
from typing import Callable


def name(s: str):
    pass


def score(s: int):
    pass


def post(f: Callable[[str]]):
    pass


def permissive():
    pass


# only accessible in post hooks
cases: dict[str]
passed: bool
