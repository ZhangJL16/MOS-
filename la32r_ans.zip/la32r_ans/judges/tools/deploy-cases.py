#!/usr/bin/python3

import argparse
import glob
import subprocess
import sys
import os
import json
import re
from typing import Sequence, Iterable

import yaml

try:
    from yaml import CLoader as Loader
except ImportError:
    from yaml import Loader

from utils import *


def merge_dict(a: dict, b: dict):
    for k, v in b.items():
        if k in a and isinstance(a[k], dict) and isinstance(v, dict):
            merge_dict(a[k], v)
        else:
            a[k] = b[k]


class Case:
    def __init__(self, i, d, *, env_name):
        self.index = i
        self.id = d['id'].replace('-', '_')
        self.score = d.get('score')
        self.after = d.get('after')
        if self.after:
            self.after = [s.replace('-', '_') for s in self.after]

        try:
            description = d['description']
        except KeyError:
            description = f'lab{self.id}'
        self.description = description

        base_name = 'lab' + self.id
        test_id = self.id
        if 'with-test' in d:
            with_test = d['with-test']
            if with_test:
                test_id = with_test.replace('-', '_')
        self.with_test = test_id

        print(f'{self.id}: {base_name} ({description})')

        self.out = {
            'env': env_name,
            'description': description,
            'compile': {
                'command': f'MOS_PROFILE=release crypt=1 make test lab={test_id} -j1',
                'timeout': d.get('compile-timeout', 20),
            },
            'execute': {
                'use-container': False,
                'command': f'$QUARTZ_PROBLEM_ROOT/utils/judge -vfed $QUARTZ_PROBLEM_ROOT/resources/{base_name}',
                "timeout": d.get('execute-timeout', 40),
            },
            'judge': {
                'command': 'utils/echo-err',
                'timeout': 5
            },
        }

        override = d.get('override')
        if override:
            merge_dict(self.out, override)
        self.override = override
        self.readme = d.get('readme')


def dump_json(o, file):
    with open(file, 'w', encoding='utf-8') as fp:
        json.dump(o, fp, indent=4, ensure_ascii=False)


def detect_cases(problem_name):
    reg = re.compile(r'lab(\d+_\d+)')
    ids = [reg.search(judge_dir)[1] for judge_dir in glob.iglob(f'judges/{problem_name}*')]
    if not ids:
        raise FileNotFoundError('No such problem: ' + problem_name)

    ids.sort()
    cases = [{'id': id} for id in ids]
    print('Auto detected cases: ', ids)
    return cases


def dump_readme(problem_name: str, cases: Sequence[Case], file: str):
    import publish
    from pytablewriter import MarkdownTableWriter, typehint
    from pytablewriter.style import Style
    with open(file, 'w', encoding='utf-8') as out:
        out.write(f'# {problem_name.capitalize()}\n\n')

        out.write('## 练习表单\n\n')
        out.write('请阅读指导书，完成下列练习：\n\n')
        publish.work(problem_name, None, dry=True)
        problem_scope = int(re.search(r'^lab(\d+)$', problem_name).group(1))
        exercises = sorted([e for e in publish.Exercise.all
                            if e.scope == problem_scope], key=lambda e: e.index())
        exercises_matrix = [
            (f'{e.scope}.{e.index() + 1}', f'`{e.name}`', f'`{e.src}`') for e in exercises]
        writer = MarkdownTableWriter(
            headers=['练习序号', '练习名', '练习所在文件'],
            value_matrix=exercises_matrix,
            type_hints=[typehint.String, typehint.String, typehint.String],
            column_styles=[Style(align='center'), Style(
                align='center'), Style(align='left')],
        )
        writer.stream = out
        writer.write_table()

        out.write('\n---\n\n## 测试点情况\n\n')
        out.write(f'本题共有 {len(cases)} 个测试点。\n\n')
        out.write('### 测试点分数分布\n\n')

        cases = sorted(cases, key=lambda c: c.id)

        def get_case_test(case: Case) -> str:
            if case.with_test and any(map(lambda c: c.id == case.with_test, cases)):
                return case.with_test
            return case.id

        cases_matrix = [[c.id,
                         c.description,
                         c.readme['command']['debug'] if c.readme and c.readme.get('command')
                         else f'`make test lab={get_case_test(c)} && make run`',
                         c.readme['command']['release'] if c.readme and c.readme.get('command')
                         else f'`MOS_PROFILE=release make test lab={get_case_test(c)} && make run`',
                         c.score] for c in cases]
        writer = MarkdownTableWriter(
            headers=['测试点编号', '测试内容', '本地测试（调试模式）', '本地测试（开启优化）', '分数'],
            value_matrix=cases_matrix,
            type_hints=[typehint.String, typehint.String, typehint.String, typehint.String,
                        typehint.String],
            column_styles=[Style(align='center'), Style(align='center'), Style(align='left'),
                           Style(align='left'), Style(align='center')],
        )
        writer.stream = out
        writer.write_table()

        out.write('''
**重要提示**：

* 在提交评测前，请同学们充分进行本地测试；只要通过了以上两种模式的本地测试，在线评测也将通过。
* 在线评测时，所有的 `.mk` 文件、所有的 `Makefile` 文件、`init/init.c`、以及 `tools/` 目录下无需填空的文件将被覆盖为标准版本，因此请同学们本地开发时，不要在这些文件中编写实际功能所依赖的代码，避免“本地测试通过，但在线评测不通过”的情况。
* 请善用 qemu 调试（单步执行），`make objdump` 等工具（反汇编）。
''')

        case_edges = '\n'.join(['\n'.join([f'Case{d.id} --> Case{c.id}' for d in cases
                                           if d.after and c.id in d.after]) for c in cases])
        if case_edges.strip():
            case_nodes = '\n'.join([f'Case{c.id}(case:{c.id})' for c in cases])
            out.write('\n\n### 测试点依赖关系（箭头方向表示依赖方向）\n')
            out.write(f'''
```mermaid
flowchart TB
{case_nodes.strip()}
{case_edges.strip()}
```
''')

        environ = os.environ.copy()
        environ['MOS_PROFILE'] = 'release'
        add_flag('MAKEFLAGS', 's', environ)

        def get_case_output(case: Case) -> Iterable[str]:
            assert not case.override
            environ['lab'] = get_case_test(case)
            compile_cmd = 'make test'
            alter_run_cmd = f'judges/lab{case.id}/run'
            if os.access(alter_run_cmd, os.X_OK):
                execute_cmd = alter_run_cmd
            else:
                execute_cmd = 'make run'
            subprocess.check_call(compile_cmd,
                                  shell=True,
                                  timeout=20,
                                  stdout=subprocess.DEVNULL,
                                  env=environ,
                                  )
            case_run_stdout = subprocess.check_output(execute_cmd,
                                                      shell=True,
                                                      timeout=40,
                                                      env=environ,
                                                      text=True,
                                                      )

            for line in case_run_stdout.splitlines():
                yield line
                if line.startswith('panic at '):
                    return

        out.write('\n### 测试点输出\n\n')
        out.write('**重要提醒**：具体输出逻辑请看 `tests/` 下对应的测试程序，以下展示的输出仅供参考。\n')
        for case in cases:
            out.write(f'\n#### 测试点 {case.id}\n')
            if case.readme and case.readme.get('annotation'):
                out.write(f'\n{case.readme["annotation"]}\n\n')
            if case.readme and case.readme.get('annotation-only'):
                continue
            if case.readme and case.readme.get('output'):
                case_output = case.readme['output']
            else:
                case_output = '\n'.join(get_case_output(case))
            out.write(f'''
```plaintext
{case_output.strip()}
```
''')
        # 避免生成的文件被部署
        subprocess.check_call(('make', 'clean'),
                              timeout=10,
                              stdout=subprocess.DEVNULL,
                              env=environ,
                              )


def main():
    os.environ['PYTHONPATH'] = os.environ.get('PYTHONPATH', '') + ':' + \
        os.path.dirname(os.path.realpath(__file__))
    file = os.environ.get('MOS_PROBLEMS_FILE', 'judges/problems.yml')
    with open(file, encoding='utf-8') as fp:
        conf = yaml.load(fp, Loader=Loader)

    if sys.argv[1] == '-l':
        return print(*(p['name'] for p in conf['problems']))

    args = argparse.ArgumentParser()
    args.add_argument('problem_name')
    args.add_argument('dest_dir')
    args.add_argument('-e', '--env-name', default='mk')
    args.add_argument('-r', '--readme', action='store_true')

    args = args.parse_args()

    problem_name = args.problem_name
    dest_dir = args.dest_dir
    env_name = args.env_name
    readme = args.readme

    for prob in conf['problems']:
        if prob['name'] == problem_name:
            break
    else:
        prob = {}

    try:
        cases = prob['cases']
    except KeyError:
        cases = detect_cases(problem_name)

    cases = [Case(i, d, env_name=env_name) for i, d in enumerate(cases, 1)]
    id_to_idx = {c.id: i for i, c in enumerate(cases, 1)}
    if len(id_to_idx) != len(cases):
        raise ValueError('Duplicated case id')

    score_left = 100
    cnt_left = 0
    for c in cases:
        if c.score is None:
            cnt_left += 1
        elif c.score <= 0:
            raise ValueError(f'Bad score: {c.score}')
        else:
            score_left -= c.score

    if score_left < 0:
        raise ValueError(f'Total score {100 - score_left} exceeds 100')

    if cnt_left:
        if score_left == 0 or score_left % cnt_left != 0:
            raise ValueError(f'Cannot distribute {score_left} score to {cnt_left} cases')

        score_left = score_left // cnt_left
        for c in cases:
            if c.score is None:
                c.score = score_left
    elif score_left:
        raise ValueError(f'Total score {100 - score_left} is less than 100')

    out_problem = {
        'testcases': list(range(1, len(cases) + 1)),
        'dependency': {
            c.index: [id_to_idx[id] for id in c.after] if c.after else []
            for c in cases
        },
        'score': {
            c.index: c.score
            for c in cases
        }
    }

    cases_dir = os.path.join(dest_dir, 'testcases')
    os.makedirs(cases_dir, exist_ok=True)
    dump_json(out_problem, os.path.join(dest_dir, 'problem.json'))
    for i, c in enumerate(cases, 1):
        dump_json(c.out, os.path.join(cases_dir, f'case{i}.json'))
    if readme:
        dump_readme(problem_name, cases, os.path.join(dest_dir, 'readme.md'))


if __name__ == '__main__':
    main()
