import os
import sys


if sys.stdout.isatty() or 'GITLAB_CI' in os.environ:
    def make_printer(prefix, level, *, file=sys.stdout):
        def wrapper(s, file=file):
            print(f'{prefix}[ {s} ]\033[0m', file=file)

        return wrapper
else:
    def make_printer(prefix, level, *, file=sys.stdout):
        def wrapper(s, file=file):
            plain = f'[MOS-{level}] {s}'
            print(plain, file=file)

        return wrapper


# bold error
bred = make_printer('\033[31m\033[01m', 'ERROR', file=sys.stderr)

# bold green to notify correctness
bgreen = make_printer('\033[32m\033[01m', 'INFO', file=sys.stderr)

# green to echo
green = make_printer('\033[32m', 'INFO')

# Error
red = make_printer('\033[31m', 'ERROR')

# warning
yellow = make_printer('\033[33m', 'WARN')


def add_flag(name, arg, environ=os.environ, *, sep=' '):
    try:
        # prepend in case of --
        environ[name] = arg + sep + environ[name]
    except KeyError:
        environ[name] = arg
