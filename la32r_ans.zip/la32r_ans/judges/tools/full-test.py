#!/usr/bin/python3

import argparse
import os
import tempfile
import subprocess
import sys
import traceback

import yaml
import publish

try:
    from yaml import CLoader as Loader
except ImportError:
    from yaml import Loader

DEFAULT_LAB = 'lab6'


def main():
    file = 'judges/mos.yml'
    with open(file, encoding='utf-8') as fp:
        conf = yaml.load(fp, Loader=Loader)

    args = argparse.ArgumentParser()
    args.add_argument('lab_name', nargs='?', default=DEFAULT_LAB)
    args.add_argument('dest_dir', nargs='?')
    args.add_argument('-e', '--explore', action='store_true')
    args.add_argument('-c', '--current-lab', action='store_true')
    args.add_argument('-d', '--debug', action='store_true')
    args.add_argument('-p', '--publish-only', action='store_true')
    args.add_argument('-a', '--publish-answer', action='store_true')
    args.add_argument('-n', '--no-clean', action='store_true')
    args = args.parse_args()

    if args.debug:
        os.environ['MAKEFLAGS'] = '-j1 --trace'

    if args.dest_dir and not os.path.isdir(args.dest_dir):
        raise NotADirectoryError(args.dest_dir)

    if args.publish_answer and not args.publish_only:
        raise ValueError('-a/--publish-answer must used with -p/--publish-only')

    lab_name = args.lab_name
    labs = []
    for stage in conf['stages']:
        lab = stage['name']
        if lab.startswith('lab'):
            labs.append(lab)
            if lab == lab_name:
                break
    else:
        raise FileNotFoundError('No such lab: ' + lab_name)

    if not args.no_clean:
        subprocess.run(['make', 'clean'])

    def do_test(dir):
        if not args.publish_only:
            os.symlink(os.path.abspath('judges'), os.path.join(dir, 'judges'))

        current_labs = []
        for lab in labs:
            current_labs.append(lab)
            print('Publishing at', current_labs)

            copy_answer = not (args.publish_only and lab == lab_name and not args.publish_answer)
            publish.work(lab, dir, answer=copy_answer,
                         update_sources=publish.Exercise.future.get(int(lab[3:]), ()) if copy_answer else ())

            if not (args.publish_only or (args.current_lab and lab != lab_name)):
                print('Judging at', current_labs)
                with open(os.path.join(dir, '.mos-this-lab'), 'w', encoding='ascii') as fp:
                    fp.write(lab[3:] + '_0')
                try:
                    subprocess.check_call(['judges/judge-all'], cwd=dir)
                except subprocess.CalledProcessError as e:
                    traceback.print_exc(file=sys.stderr)
                    print(f'full-test: {lab} failed!', file=sys.stderr)
                    if args.explore:
                        input(dir + '\nSend an Enter to continue: ')
                    sys.exit(e.returncode)

            if args.explore:
                input(dir + '\nSend an Enter to continue: ')

    if args.dest_dir:
        do_test(args.dest_dir)
    else:
        with tempfile.TemporaryDirectory() as directory:
            do_test(directory)


if __name__ == '__main__':
    main()
