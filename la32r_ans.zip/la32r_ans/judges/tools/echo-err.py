#!/usr/bin/python3

import json
import sys


def main():
    out = json.load(sys.stdin)['err']
    print(out)
    sys.exit(0 if 'Passed MOS test' in out else 1)


if __name__ == '__main__':
    main()
