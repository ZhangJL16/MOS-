#!/usr/bin/python3
import re
import os
import glob
import sys
import difflib
import pathlib
from contextlib import redirect_stdout
from typing import Sequence

REG_LABEL = re.compile(r'\\label{exercise(?:[\d\-]*)(.+)}')
REG_HREF = re.compile(r'\\hyperref\[exercise(?:[\d\-]*)(.+)\]')


def diff(*args):
    r = ''.join(difflib.unified_diff(*args))
    if r:
        sys.stdout.write(r)
        if not os.path.exists('diff.html'):
            print('Generated diff.html', file=sys.stderr)
            with open('diff.html', 'w', encoding='utf-8') as fp:
                fp.write(difflib.HtmlDiff().make_file(*args))
        else:
            print('diff.html already exists', file=sys.stderr)
        sys.exit(1)


def publish_digest() -> Sequence[str]:
    cwd = os.getcwd()
    mos_root = os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../..'))
    os.chdir(mos_root)
    import publish

    with open(os.devnull, 'w', encoding='utf-8') as nul:
        with redirect_stdout(nul):
            for i in range(6, 0, -1):
                publish.work(f'lab{i}', None, dry=True)
                if len(publish.loaded_exercise_scopes) == 6:
                    break

    os.chdir(cwd)
    exercises = publish.Exercise.all
    exercises.sort(key=lambda e: (e.scope, e.index()))
    return tuple(f'{e.scope}: {e.name}\n' for e in exercises)


def chunks(content: str, reg: re.Pattern, no: int) -> Sequence[str]:
    return tuple(f'{no}: {m}\n' for m in reg.findall(content))


def chapter_digest(chapter_dir: str, no: int) -> Sequence[str]:
    rule = os.path.join(chapter_dir, f'{no}-*.tex')
    files = glob.glob(rule)
    if len(files) != 1:
        raise FileNotFoundError(f'{rule}: {files}')
    src = files[0]
    with open(src, encoding='utf-8') as fp:
        s = fp.read()
    label_digest = chunks(s, REG_LABEL, no)
    href_digest = chunks(s, REG_HREF, no)
    file = os.path.basename(src)
    diff(label_digest, href_digest, file + ' (labels)', file + ' (hyperrefs)')
    return label_digest


def detect_chapter_dir() -> str:
    if len(sys.argv) >= 2:
        r = sys.argv[1]
        if os.path.isdir(r):
            return r
    else:
        for p in pathlib.Path(os.getcwd()).parents:
            p = p / 'guide-book/guide-book/chapters'
            if p.is_dir():
                print(f'Found chapters at', p, file=sys.stderr)
                return str(p)
    print(f'Usage: {sys.argv[0]} [chapter-dir]', file=sys.stderr)
    sys.exit(1)


def main():
    chapter_dir = detect_chapter_dir()
    a = publish_digest()
    b = []
    for no in range(1, 7):
        b.extend(chapter_digest(chapter_dir, no))
    diff(a, b, 'mos', 'guide-book')
    sys.stdout.writelines(a)


if __name__ == '__main__':
    main()
