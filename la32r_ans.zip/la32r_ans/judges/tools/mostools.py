import subprocess
import time
import sys
import atexit
import threading
import queue
import traceback


def after(millis):
    time.sleep(millis / 1000)


class MOS:
    def __init__(self, cmd=None):
        if cmd is None:
            cmd = ['make', 'run']
        self.ch = subprocess.Popen(cmd,
                                   stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE,
                                   )
        self.tee = threading.Thread(target=self._worker)
        self.tee.start()
        self.q = queue.SimpleQueue()

    def __enter__(self):
        atexit.register(self.join)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            traceback.print_exc(file=sys.stderr)
        self.join()

    def _worker(self):
        try:
            for line in self.ch.stdout:
                sys.stdout.buffer.write(line)
                sys.stdout.flush()
                self.q.put(line)
        except BrokenPipeError:
            # judger killed my child
            pass

    def send(self, s):
        if isinstance(s, str):
            s = s.encode('utf-8')
        self.ch.stdin.write(s)
        try:
            self.ch.stdin.flush()
        except BrokenPipeError:
            yellow("The procedure has been finished")

    def expect(self, s):
        if isinstance(s, str):
            s = s.encode('utf-8')
        while True:
            line = self.q.get()
            if s in line:
                return line

    def join(self):
        if not self.ch:
            return

        try:
            self.tee.join()
        finally:
            self.ch.wait()
            self.ch = None
