#!/usr/bin/python3

# 下发 lab{x}:
# $ judges/publish lab{x} {学生仓库目录}
# $ echo {x}_0 > {学生仓库目录}/.mos-this-lab  # 作用见 Makefile

from __future__ import annotations
import argparse
import glob
import shutil
import os
import re
import subprocess
import pathlib
from functools import partial
from typing import Callable, Iterable, Optional

import yaml

try:
    from yaml import CLoader as Loader
except ImportError:
    from yaml import Loader

from utils import *


class BadSyntax(RuntimeError):
    pass


class BadExercise(BadSyntax):
    pass


class Exercise:
    BEGIN_REG = re.compile(r'- MOS EXERCISE (\d+) ([\w\-]+)(?: AFTER ([\w\-]+))? BEGIN -')
    all: list[Exercise] = []
    map: dict[str, Exercise] = {}
    future: dict[int, set[str]] = {}

    def __init__(self, m: re.Match, src: str, src_scope: int) -> None:
        self.scope = int(m[1])
        self.name = m[2]
        self.prev_name = m[3]
        self.src = src
        self.src_scope = src_scope
        self.line_no = -1
        self._index = None

        self.blank_cnt = 0
        self.blank_loc = 0

        # current_scope: 当前正在尝试下发的 lab。
        # self.src_scope: 该 Exercise 所在的源文件 (self.src) 应当在该 lab 被下发。在 mos.yml 中定义。
        # self.scope: 该 Exercise 编号中的 lab，即应当在该 lab 被学生完成。在源文件中定义。
        # Exercise 被完成的 lab 不能早于被下发的 lab。
        if self.src_scope > self.scope:
            raise BadExercise(f'bad exercise scope: {self}: {self.src_scope} > {self.scope}')

    def clear(self):
        self.blank_cnt = 0
        self.blank_loc = 0

    def index(self) -> int:
        if self._index is None:
            if self.prev_name is None:
                self._index = 0
            else:
                self._index = -1  # pending
                try:
                    self._index = self.map[self.prev_name].index() + 1
                except (KeyError, BadExercise):
                    self._index = None
                    raise
        elif self._index == -1:
            self._index = None
            raise BadExercise(f'circular exercise: {self}')
        return self._index

    def header(self) -> str:
        return f'Exercise {self.scope}.{self.index() + 1}'

    def __str__(self) -> str:
        i = self._index
        if i is None or i < 0:
            i = '?'
        else:
            i += 1
        name = self.name
        if self.prev_name:
            name += f', after {self.prev_name}'
        return f'Exercise {self.scope}.{i} ({name})'

    @classmethod
    def begin(cls, line: str, src: str, src_scope: int) -> Optional['Exercise']:
        m = cls.BEGIN_REG.search(line)
        if m:
            e = cls(m, src, src_scope)
            if e.name in cls.map:
                raise BadExercise(f'duplicate exercise: {e}')
            cls.map[e.name] = e
            cls.all.append(e)
            if e.scope > src_scope:
                # full-test should check 'future' and republish this file at that future scope.
                print(f'Future exercise: {e} at {src} > {src_scope}')
                try:
                    cls.future[e.scope].add(src)
                except KeyError:
                    cls.future[e.scope] = {src}
            return e

    @classmethod
    def get(cls, line: str) -> Optional['Exercise']:
        m = cls.BEGIN_REG.search(line)
        if m:
            e = cls.map[m[2]]
            assert e.scope == int(m[1])
            assert e.prev_name == m[3]
            return e

    @classmethod
    def init(cls):
        vis = set()
        for e in cls.all:
            try:
                t = (e.scope, e.index())
            except KeyError:
                continue
            if t in vis:
                raise BadExercise(f'conflict exercise: {e}')
            vis.add(t)


def get_tracked_paths():
    res = set()

    def ins(path):
        if not path or path in res:
            return
        res.add(path)
        ins(os.path.dirname(path))

    files = subprocess.check_output(['git', 'ls-files', '-z']).rstrip(b'\0').decode().split('\0')
    for f in files:
        ins(f)
    return res


SOURCE_SUFFIXS = frozenset(('Makefile', '.mk', '.c', '.h', '.S', '.lds', '.gitignore'))
copy_answer = False
source_copy_tasks = []
current_scope = None
loaded_exercise_scopes = set()
tracked_paths = get_tracked_paths()

with open('judges/mos.yml', encoding='utf-8') as fp:
    mos_stages = {stage['name']: stage for stage in yaml.load(fp, Loader=Loader)['stages']}


def strip_indent(line: str) -> str:
    # keep indents before a C-style comment
    return line[:line.find('/')]


def source_copy(src, dst, dry):
    lines = []
    all_exercise_blank_line_idxs = []
    hide_cnt = 0
    bare_blank_cnt = 0
    bare_blank_loc = 0
    answered_lns = set()
    with open(src, encoding='utf-8') as fp:
        hide = False
        uncomment = False
        exercise = None
        exercise_blank_line_idxs = []

        def handle_directive(ln, line):
            nonlocal hide_cnt, bare_blank_cnt, bare_blank_loc
            nonlocal hide, uncomment, exercise, exercise_blank_line_idxs

            def err_on(cond):
                if cond:
                    raise BadSyntax(f'{src}:{ln}: {line.strip()}')

            if '- MOS BLANK BEGIN -' in line:
                err_on(hide or uncomment)
                if exercise and ' quiet' not in line:
                    exercise_blank_line_idxs.append(len(lines))
                    if line.rstrip().endswith('\\'):
                        lines.append(strip_indent(line) + '/* {} */  \\\n')
                    else:
                        lines.append(strip_indent(line) + '/* {} */\n')
                hide = True
                hide_cnt = 0
            elif '- MOS BLANK END -' in line:
                err_on(not hide or uncomment)
                if exercise:
                    exercise.blank_cnt += 1
                    exercise.blank_loc += hide_cnt
                else:
                    bare_blank_cnt += 1
                    bare_blank_loc += hide_cnt
                hide = False
            elif '- MOS UNCOMMENT BEGIN -' in line:
                err_on(uncomment or hide)
                uncomment = True
            elif '- MOS UNCOMMENT END -' in line:
                err_on(not uncomment or hide)
                uncomment = False
            elif '- MOS EXERCISE END -' in line:
                err_on(uncomment or hide or not exercise)
                if not exercise.blank_cnt:
                    raise BadExercise(f'no blank in: {exercise}')
                print(
                    f'{src}:{exercise.line_no}: {exercise}: {exercise.blank_cnt} blanks, {exercise.blank_loc} loc')
                tot_no = len(exercise_blank_line_idxs)
                for no, idx in enumerate(exercise_blank_line_idxs, 1):
                    repl = f'{exercise.header()}: Your code here.'
                    if tot_no > 1:
                        repl += f' ({no}/{tot_no})'
                    lines[idx] = lines[idx].format(repl)
                all_exercise_blank_line_idxs.append(exercise_blank_line_idxs)
                exercise_blank_line_idxs = []
                exercise = None
            else:
                e = Exercise.get(line)
                if e:
                    err_on(uncomment or hide or exercise)
                    e.clear()
                    assert e.src == src
                    exercise = e
                    e.line_no = ln
                else:
                    raise BadSyntax(f'{src}:{ln}: bad directive: {line.strip()}')

        for ln, line in enumerate(fp, 1):
            if '- MOS' in line:
                handle_directive(ln, line)
            elif copy_answer and exercise and exercise.scope <= current_scope:
                answered_lns.add(ln)
                lines.append(line)
            elif hide:
                if line.strip():
                    hide_cnt += 1
            else:
                if uncomment:
                    for pat in ('// ', '/* ', ' */'):
                        line = line.replace(pat, '', 1)
                lines.append(line)

        if uncomment:
            raise BadSyntax(f'{src}: unclosed uncomment block')
        if hide:
            raise BadSyntax(f'{src}: unclosed blank block')
        if exercise:
            raise BadSyntax(f'{src}: unclosed exercise: {exercise}')

    if bare_blank_cnt:
        yellow(f'{src}: {bare_blank_cnt} bare blanks, {bare_blank_loc} loc', file=sys.stdout)

    if dry:
        return

    tot_lines = len(lines)
    for idxs in all_exercise_blank_line_idxs:
        for idx in idxs:
            if idx + 1 < tot_lines and lines[idx + 1].strip() and idx + 1 not in answered_lns:
                lines[idx] += '\n'

    with open(dst, 'w', encoding='utf-8') as fp:
        fp.writelines(lines)
    shutil.copymode(src, dst, follow_symlinks=False)


def mos_copy(src: str,
             dst: Optional[str],
             source_scope: str, *,
             follow_symlinks: bool = False,
             dry: bool = False,
             as_raw: bool = False,
             dir_ignore: bool | Optional[Callable] = False,
             ):
    if pathlib.PurePath(src).as_posix() not in tracked_paths:
        return

    if dst and os.path.lexists(dst):
        raise FileExistsError(dst)

    # Never follow symlinks.
    try:
        real = os.readlink(src)
    except OSError:
        pass
    else:
        print(f'{src}: linking from {real}')
        if not dry:
            os.symlink(real, dst)
        return

    if os.path.isdir(src):
        if dir_ignore is False:
            raise NotADirectoryError(src)
        func = partial(mos_copy, source_scope=source_scope, dry=dry, as_raw=as_raw)
        if dry:
            dry_copytree(src, func, ignore=dir_ignore)
        else:
            shutil.copytree(src, dst, symlinks=True, dirs_exist_ok=True,
                            copy_function=func, ignore=dir_ignore)
        return

    if not as_raw:
        base, ext = os.path.splitext(src)
        if ext in SOURCE_SUFFIXS or (not ext and os.path.basename(base) in SOURCE_SUFFIXS):
            if source_scope not in loaded_exercise_scopes:
                with open(src, encoding='utf-8') as fp:
                    for line in fp:
                        Exercise.begin(line, src, source_scope)
            if source_scope == current_scope:
                source_copy_tasks.append((src, dst, dry))
            return

    if not dry:
        shutil.copy(src, dst, follow_symlinks=False)


def resolve_globs(tree) -> Iterable[str]:
    for rule in flatten_globs(tree):
        # Convert Windows separators to POSIX.
        raw = [pathlib.PurePath(p).as_posix() for p in glob.iglob(rule)]
        a = [f for f in raw if f in tracked_paths]
        if not a:
            raise FileNotFoundError(
                f'{rule}: no files found (untracked: {raw}, perhaps you forgot to add them to git?)'
                if raw else rule
            )
        yield from a


def flatten_globs(o, pre=None) -> Iterable[str]:
    if isinstance(o, str):
        if pre:
            o = os.path.join(pre, o)
        yield o
    elif isinstance(o, dict):
        for dir, inner in o.items():
            if pre:
                dir = os.path.join(pre, dir)
            yield from flatten_globs(inner, dir)
    else:
        for ent in o:
            yield from flatten_globs(ent, pre)


def resolve_stage(stage: dict[str]):
    files = resolve_globs(stage.get('include', ()))
    raw_files = resolve_globs(stage.get('raw-include', ()))

    if stage.get('deduplicate'):
        files = frozenset(files)
        raw_files = frozenset(raw_files)

    excl = stage.get('ignore-names')
    if excl:
        ignore = shutil.ignore_patterns(*excl)
        excl = frozenset(excl)

        def not_excl(path):
            return os.path.basename(path) not in excl

        files = filter(not_excl, files)
        raw_files = filter(not_excl, raw_files)
    else:
        ignore = None

    return files, raw_files, ignore


def dry_copytree(src, copy_function, ignore=None):
    # FIXME: os.walk doesn't take `ignore` when going down to directorys,
    # so `ignore-names` works only on non-directory files for now.
    for root, _, files in os.walk(src):
        if ignore:
            ignored = frozenset(ignore(root, files))
            files = filter(lambda name: name not in ignored, files)
        for name in files:
            copy_function(os.path.join(root, name), None)


def find_stage(name):
    return mos_stages[name]


def clear():
    # Static containers in Exercise are not cleared, so that we can keep
    # track of exercises in all scopes and check for duplicates.
    # Otherwise, full-test may be unable to republish an older file without
    # its accompanying exercises.
    source_copy_tasks.clear()


def work(stage_name: str, dest_dir: Optional[str], *,
         dry: bool = False,
         answer: bool = False,
         update_sources: Iterable[str] = (),
         ):
    clear()
    files, raw_files, ignore = resolve_stage(find_stage(stage_name))

    global copy_answer, current_scope
    root = dest_dir
    copy_answer = answer

    if not dry and not (root and os.path.isdir(root)):
        raise NotADirectoryError(root)

    try:
        current_scope = int(stage_name[3:])
    except ValueError:
        current_scope = 0

    def copy(file, as_raw=False):
        if dry:
            dst = None
        else:
            dst = os.path.join(root, file)
            dir = os.path.dirname(dst)
            if not os.path.isdir(dir):
                os.makedirs(dir)
        mos_copy(file, dst, source_scope=current_scope, dry=dry, dir_ignore=ignore, as_raw=as_raw)

    for file in files:
        copy(file)
    loaded_exercise_scopes.add(current_scope)

    # Use numbered indices since we are modifying the list.
    i = 0
    while i < len(Exercise.all):
        e = Exercise.all[i]
        i += 1
        if e.prev_name and e.prev_name not in Exercise.map:
            for s in range(e.scope, 0, -1):
                if s in loaded_exercise_scopes:
                    continue
                alt_files, _, alt_ignore = resolve_stage(find_stage('lab' + str(s)))
                for file in alt_files:
                    mos_copy(file, None, source_scope=s, dry=True, dir_ignore=alt_ignore)
                loaded_exercise_scopes.add(s)
                if e.prev_name in Exercise.map:
                    break
            else:
                raise BadExercise(f'Cannot resolve {e}')
            print(f'Resolving {e} from {loaded_exercise_scopes}')

    Exercise.init()
    for task in source_copy_tasks:
        source_copy(*task)

    for file in raw_files:
        copy(file, as_raw=True)

    for src in update_sources:
        # To allow exercises from more than 2 scopes in a single file, we will need
        # to copy answer of all older and current exercises while republishing it,
        # instead of leave full-test to override with the raw file.
        print('Updating', src)
        if root:
            dst = os.path.join(root, src)
            if not os.path.isfile(dst):  # must override
                raise FileNotFoundError(dst)
        else:
            dst = None
        source_copy(src, dst, dry)


def main():
    args = argparse.ArgumentParser()
    args.add_argument('stage_name')
    args.add_argument('dest_dir', nargs='?')
    args.add_argument('-d', '--dry', action='store_true')
    args.add_argument('-a', '--answer', action='store_true')
    args = args.parse_args()
    work(args.stage_name, args.dest_dir, dry=args.dry, answer=args.answer)
    print('')
    for e in sorted(filter(lambda e: e.src_scope == current_scope, Exercise.all),
                    key=lambda e: (e.scope, e.index())):
        (green if e.scope == current_scope else yellow)(
            f'{e} at {e.src}:{e.line_no}',
            file=sys.stdout
        )


if __name__ == '__main__':
    main()
