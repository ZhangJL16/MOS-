#!/usr/bin/python3

from __future__ import annotations

import argparse
import os
import sys
from itertools import groupby
from typing import TextIO, Sequence

from pytablewriter import MarkdownTableWriter, typehint
from pytablewriter.style import Style

import publish


def generate_wiki_page(exercises: Sequence[publish.Exercise], out: TextIO) -> None:
    try:
        link = os.environ['CI_PROJECT_URL'] + '/-/tree/master/'
    except KeyError:
        link = ''

    exercise_items = tuple(
        (k, tuple(v))
        for k, v in groupby(sorted(exercises, key=lambda e: (e.scope, e.index())), key=lambda e: e.scope)
    )

    out.write('## Statistic\n\n')

    statistic_matrix = [[i, len(l), sum(e.blank_cnt for e in l), sum(e.blank_loc for e in l)]
                        for i, l in exercise_items] + [[
                            'Total', len(exercises),
                            sum(e.blank_cnt for e in exercises),
                            sum(e.blank_loc for e in exercises),
                        ]]

    statistic_matrix = [r + [f'{r[3] / r[2]:.2f}', f'{r[3] / r[1]:.2f}'] for r in statistic_matrix]

    writer = MarkdownTableWriter(
        headers=['Lab', 'NoE (Number of Exercises)', 'NoB (Number of Blanks)',
                 'LoC (Lines of Code)', 'LoC / NoB', 'LoC / NoE'],
        value_matrix=statistic_matrix,
        type_hints=[typehint.String, typehint.Integer, typehint.Integer,
                    typehint.Integer, typehint.String, typehint.String],
        column_styles=[Style(align='center'), Style(align='center'),
                       Style(align='center'), Style(align='center'),
                       Style(align='center'), Style(align='center')],
    )
    writer.stream = out
    writer.write_table()
    out.write('\n---\n\n')

    for lab, exercise_list in exercise_items:
        writer = MarkdownTableWriter(
            value_matrix=[[f'{e.scope}.{e.index() + 1}', f'`{e.name}`',
                           f'[{e.src}:{e.line_no}]({link}{e.src}#L{e.line_no})',
                           e.blank_cnt, e.blank_loc, f'{e.blank_loc / e.blank_cnt:.2f}'
                           ] for e in exercise_list],
            headers=['Exercise', 'Name', 'File', 'NoB', 'LoC', 'LoC / NoB'],
            type_hints=[typehint.String, typehint.String, typehint.String,
                        typehint.Integer, typehint.Integer, typehint.String],
            column_styles=[Style(align='center'), Style(align='center'),
                           Style(align='left'),
                           Style(align='center'), Style(align='center'), Style(align='center')],
        )
        out.write(f'## Lab{lab} Exercises\n\n')
        writer.stream = out
        writer.write_table()
        out.write('\n')


def main():
    args = argparse.ArgumentParser()
    args.add_argument('file', nargs='?', type=str)
    args = args.parse_args()
    for i in range(1, 7):
        publish.work(f'lab{i}', None, dry=True)
    if args.file:
        with open(args.file, 'w', encoding='utf-8') as fp:
            generate_wiki_page(publish.Exercise.all, fp)
    else:
        generate_wiki_page(publish.Exercise.all, sys.stdout)


if __name__ == '__main__':
    main()
