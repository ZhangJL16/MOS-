#include <stdio.h>

int main() {
	puts("Hello, world!");
	return 0;
}
